This is a variant of the Pintos Operating System for use as part of Operating Systems module at the University of the West of England (UWE).
